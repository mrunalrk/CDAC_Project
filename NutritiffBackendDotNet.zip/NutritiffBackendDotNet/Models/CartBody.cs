﻿namespace NutritiffBackendDotNet.Models
{
    public class CartBody
    {
        public string? customerId { get; set; }
        public string? productId { get; set; }
    }
}
