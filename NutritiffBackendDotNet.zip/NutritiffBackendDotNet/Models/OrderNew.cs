﻿namespace NutritiffBackendDotNet.Models
{
    public class OrderNew
    {
        public int OrderId { get; set; }
        public int TiffinId { get; set; }
        public int Quantity { get; set; }
        public double Price { get; set; }
    }
}
