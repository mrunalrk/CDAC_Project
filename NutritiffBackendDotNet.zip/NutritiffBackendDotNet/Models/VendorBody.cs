﻿namespace NutritiffBackendDotNet.Models
{
    public class VendorBody
    {
        public string? Email { get; set; }
        public string? Password { get; set; }
    }
}
